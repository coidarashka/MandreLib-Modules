api_id = "26529238"
api_hash = "b95e013f0c245437943b4e8851f7c702"
# Префикс команд
prefix = "."
